#!/bin/sh
set -eu
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec "$script_dir/plugins/wufan-workstation-readonly/setup/setup-unix.sh" "$@"
