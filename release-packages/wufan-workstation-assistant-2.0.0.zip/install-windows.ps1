$ErrorActionPreference = "Stop"
$installer = Join-Path $PSScriptRoot "plugins\wufan-workstation-readonly\setup\setup-windows.ps1"
& $installer @args
exit $LASTEXITCODE
